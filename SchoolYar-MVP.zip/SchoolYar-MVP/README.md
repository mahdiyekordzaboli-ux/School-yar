# مدرسه‌یار هوشمند — نسخه اجرایی اولیه

نسخه MVP قابل اجرا و آماده انتشار وب.

## اجرا در کامپیوتر
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

سپس:
`http://127.0.0.1:8000`

## حساب‌های آزمایشی
همه حساب‌ها رمز `123456` دارند:
- admin — مدیر
- deputy — معاون
- teacher — معلم / هنرآموز
- student — دانش‌آموز
- parent — والد

> این حساب‌ها فقط برای دمو هستند و قبل از استفاده واقعی باید حذف/تغییر شوند.

## انتشار
فایل `render.yaml` برای استقرار روی Render آماده شده است.

ساخته شده توسط مهندس مهدیه کرد
