const $ = s => document.querySelector(s);
let selectedRole = "admin";
document.querySelectorAll(".roles button").forEach(btn => {
  btn.addEventListener("click", () => {
    selectedRole = btn.dataset.user;
    $("#username").value = selectedRole;
    $("#password").value = "123456";
    $("#loginMsg").textContent = "";
  });
});

$("#loginBtn").addEventListener("click", async () => {
  $("#loginMsg").textContent = "در حال ورود...";
  try {
    const r = await fetch("/api/login", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username:$("#username").value, password:$("#password").value})
    });
    const data = await r.json();
    if(!r.ok) throw new Error(data.detail || "خطا در ورود");
    $("#loginView").classList.add("hidden");
    $("#dashboard").classList.remove("hidden");
    $("#welcome").textContent = `خوش آمدید، ${data.user.full_name}`;
    $("#role").textContent = data.user.role_title;
    loadDashboard();
  } catch(e) { $("#loginMsg").textContent = e.message; }
});

async function loadDashboard(){
  const data = await (await fetch("/api/dashboard")).json();
  $("#students").textContent = data.stats.students;
  $("#classes").textContent = data.stats.classes;
  $("#attendance").textContent = data.stats.attendance + "%";
  $("#studentRows").innerHTML = data.students.map(s =>
    `<tr><td>${s.full_name}</td><td>${s.class_name}</td><td>${s.average}</td><td>${s.attendance}%</td></tr>`
  ).join("");
  $("#notices").innerHTML = data.notices.map(n =>
    `<div class="notice"><b>${n.title}</b><span>${n.body}</span></div>`
  ).join("");
}
$("#logout").addEventListener("click", () => location.reload());
