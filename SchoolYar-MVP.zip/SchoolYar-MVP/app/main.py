from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import sqlite3, hashlib, secrets
from pathlib import Path

BASE = Path(__file__).resolve().parent
DB = BASE / "schoolyar.db"

app = FastAPI(title="مدرسه‌یار هوشمند", version="0.1.0")
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")

ROLES = {
    "admin": "مدیر",
    "deputy": "معاون",
    "teacher": "معلم / هنرآموز",
    "student": "دانش‌آموز",
    "parent": "والد",
}

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password: str, salt: str | None = None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000).hex()
    return f"{salt}${digest}"

def verify_password(password, stored):
    try:
        salt, digest = stored.split("$", 1)
        check = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000).hex()
        return secrets.compare_digest(check, digest)
    except Exception:
        return False

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        class_name TEXT NOT NULL,
        average REAL DEFAULT 0,
        attendance REAL DEFAULT 100
    );
    CREATE TABLE IF NOT EXISTS notices(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        body TEXT NOT NULL
    );
    """)
    count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if count == 0:
        demo = [
            ("admin", "123456", "مدیر مدرسه", "admin"),
            ("deputy", "123456", "معاون مدرسه", "deputy"),
            ("teacher", "123456", "هنرآموز نمونه", "teacher"),
            ("student", "123456", "دانش‌آموز نمونه", "student"),
            ("parent", "123456", "والد دانش‌آموز نمونه", "parent"),
        ]
        for username, password, name, role in demo:
            conn.execute(
                "INSERT INTO users(username,password_hash,full_name,role) VALUES(?,?,?,?)",
                (username, hash_password(password), name, role)
            )
        students = [
            ("علی رضایی", "دهم کامپیوتر", 18.45, 96),
            ("سارا محمدی", "دهم کامپیوتر", 17.80, 91),
            ("مریم احمدی", "یازدهم کامپیوتر", 19.10, 98),
        ]
        conn.executemany(
            "INSERT INTO students(full_name,class_name,average,attendance) VALUES(?,?,?,?)",
            students
        )
        conn.execute("INSERT INTO notices(title,body) VALUES(?,?)",
                     ("خوش آمدید", "به نسخه آزمایشی مدرسه‌یار خوش آمدید."))
        conn.commit()
    conn.close()

init_db()

class LoginRequest(BaseModel):
    username: str
    password: str

def get_user(username: str):
    conn = db()
    row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    return row

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.post("/api/login")
def login(data: LoginRequest):
    user = get_user(data.username.strip())
    if not user or not verify_password(data.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="نام کاربری یا رمز عبور نادرست است")
    return {
        "ok": True,
        "user": {
            "id": user["id"],
            "username": user["username"],
            "full_name": user["full_name"],
            "role": user["role"],
            "role_title": ROLES[user["role"]],
        }
    }

@app.get("/api/dashboard")
def dashboard():
    conn = db()
    students = [dict(x) for x in conn.execute(
        "SELECT id,full_name,class_name,average,attendance FROM students ORDER BY id"
    ).fetchall()]
    notices = [dict(x) for x in conn.execute(
        "SELECT id,title,body FROM notices ORDER BY id DESC LIMIT 5"
    ).fetchall()]
    conn.close()
    return {
        "students": students,
        "notices": notices,
        "stats": {
            "students": len(students),
            "teachers": 8,
            "classes": 6,
            "attendance": round(sum(s["attendance"] for s in students)/len(students), 1) if students else 0,
        }
    }

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "SchoolYar", "version": "0.1.0"}
